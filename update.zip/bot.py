import sys
sys.stdout.reconfigure(line_buffering=True)
sys.stderr.reconfigure(line_buffering=True)
import traceback
import os
import io
import sqlite3
import asyncio
import time
import discord
import hashlib
import aiohttp
import gc
import ctypes
from PIL import Image

# Enforce an absolute 64 Megapixel ceiling to prevent decompression bombs (DoS)
Image.MAX_IMAGE_PIXELS = 67108864

from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv
from typing import Optional, Set, Union, Dict, Any

import database
import ai_engine

# Load .env variables from potential locations
load_dotenv(".env")
load_dotenv("reference_images/.env")

# Production Constants - Hardened: Max size is 8MB (8388608 bytes)
MAX_FILE_SIZE = 26214400  # 25MB (25 * 1024 * 1024 bytes)

MAX_QUEUE_DEPTH = 3
queue_semaphore = asyncio.Semaphore(1)

# Module level queue for backward compatibility with existing tests
verification_queue = asyncio.Queue()

# Thread-safe global button/interaction cooldown tracker (1 request per user per 60 seconds)
BUTTON_COOLDOWNS = {}
active_sessions: Dict[int, Any] = {}

def check_button_cooldown(user_id: int) -> Optional[float]:
    """
    Tracks and enforces interaction cooldowns (60 seconds) for button/select interactions.
    """
    current_time = time.time()
    last_time = BUTTON_COOLDOWNS.get(user_id, 0)
    if current_time - last_time < 60.0:
        return 60.0 - (current_time - last_time)
    BUTTON_COOLDOWNS[user_id] = current_time
    return None

def verify_magic_bytes(data: bytes) -> bool:
    """
    Verifies magic byte signatures for JPEG, PNG, or WebP.
    """
    if len(data) < 3:
        return False
    # JPEG check
    if data.startswith(b'\xFF\xD8\xFF'):
        return True
    # PNG check
    if data.startswith(b'\x89\x50\x4E\x47'):
        return True
    # WebP check (RIFF....WEBP)
    if len(data) >= 12 and data.startswith(b'RIFF') and data[8:12] == b'WEBP':
        return True
    return False

# In-memory TOCTOU prevention locks
LOCKS = {}
LOCKS_MUTEX = asyncio.Lock()

async def get_lock(key: Any) -> asyncio.Lock:
    async with LOCKS_MUTEX:
        if key not in LOCKS:
            LOCKS[key] = asyncio.Lock()
        return LOCKS[key]

class VerificationBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix="!", intents=intents)
        # In-memory set for tracking active in-flight verification requests
        self.processing_users: Set[int] = set()
        # Aliasing instance-level verification_queue to the global verification_queue
        self.verification_queue = verification_queue
        # Cache of audit log message IDs and their original embeds to detect tampering
        self.sent_audit_logs: Dict[int, discord.Embed] = {}

    async def setup_hook(self) -> None:
        # Initialize database
        database.init_db()
        
        # Register persistent views
        self.add_view(VerifyDropdownView())
        self.add_view(DMStartCancelView())
        self.add_view(StaffTriageView())
        self.add_view(StaffCorrectionView())
        self.add_view(RequestCorrectionView())
        
        # Sync slash commands
        await self.tree.sync()
        print("Bot persistent views registered and slash commands synced.")
        
        # Start the background worker
        try:
            self.loop.create_task(self.verification_worker())
        except AttributeError:
            asyncio.create_task(self.verification_worker())

    async def verification_worker(self) -> None:
        """
        Background worker strictly adhering to the requested try...except...finally structure.
        Ensures all synchronous blocking calls are run via asyncio.to_thread().
        """
        while True:
            item = await self.verification_queue.get()
            user_id = item["user_id"]
            url = item["url"]
            channel_id = item["channel_id"]
            user_id_str = str(user_id)
            print(f"[WORKER] Picked up verification job for user {user_id}. Starting analysis...", flush=True)

            channel = self.get_channel(channel_id)
            if not channel:
                try:
                    channel = await self.fetch_channel(channel_id)
                except Exception:
                    channel = None

            async with queue_semaphore:
                image_bytes = None
                status_msg = None
                optimized_bytes = None
                try:
                    if channel:
                        status_msg = await channel.send("⏳ Analyzing your SAI document... Please note: Verification may take a few moments while we audit your document. Thank you for your patience!")
                    
                    # Download raw image bytes from url using async aiohttp.ClientSession streaming download with 15MB limit
                    MAX_DOWNLOAD_SIZE = 15 * 1024 * 1024
                    async with aiohttp.ClientSession() as session:
                        async with session.get(url) as resp:
                            if resp.status != 200:
                                raise RuntimeError(f"Failed to download image from URL, status {resp.status}")
                            
                            if resp.content_length and resp.content_length > MAX_DOWNLOAD_SIZE:
                                user = self.get_user(user_id) or await self.fetch_user(user_id)
                                if user:
                                    try:
                                        await user.send("❌ File exceeds maximum 15MB limit.")
                                    except discord.Forbidden:
                                        print(f"[GATEWAY] Warning: Cannot deliver DM to user {user_id}. DMs closed or blocked.")
                                    except Exception:
                                        pass
                                if status_msg:
                                    try:
                                        await status_msg.edit(content="❌ File exceeds maximum 15MB limit.")
                                    except Exception:
                                        pass
                                continue
                            
                            chunks = []
                            total_bytes = 0
                            async for chunk in resp.content.iter_chunked(65536):
                                total_bytes += len(chunk)
                                if total_bytes > MAX_DOWNLOAD_SIZE:
                                    break
                                chunks.append(chunk)
                            
                            if total_bytes > MAX_DOWNLOAD_SIZE:
                                user = self.get_user(user_id) or await self.fetch_user(user_id)
                                if user:
                                    try:
                                        await user.send("❌ File exceeds maximum 15MB limit.")
                                    except discord.Forbidden:
                                        print(f"[GATEWAY] Warning: Cannot deliver DM to user {user_id}. DMs closed or blocked.")
                                    except Exception:
                                        pass
                                if status_msg:
                                    try:
                                        await status_msg.edit(content="❌ File exceeds maximum 15MB limit.")
                                    except Exception:
                                        pass
                                continue
                            
                            image_bytes = b"".join(chunks)

                    # Magic Bytes File Signature Verification: Do NOT trust Discord's attachment.content_type
                    if not verify_magic_bytes(image_bytes):
                        if status_msg:
                            await status_msg.edit(content="❌ Invalid file. The uploaded image does not have a valid file signature (JPEG, PNG, or WebP).")
                        continue

                    # Optimize image and catch PIL Decompression Bomb Protection
                    try:
                        optimized_bytes = await asyncio.to_thread(ai_engine.optimize_image, image_bytes)
                    except Image.DecompressionBombError as dbe:
                        print(f"Decompression bomb detected: {dbe}")
                        if status_msg:
                            await status_msg.edit(content="❌ Image processing aborted: Decompression bomb detected (exceeded 8 Megapixel ceiling).")
                        continue
                    except Exception as e:
                        print(f"Error reading attachment: {e}")
                        optimized_bytes = None

                    if optimized_bytes is None:
                        if status_msg:
                            await status_msg.edit(content="❌ Invalid file. The uploaded image is corrupted or invalid.")
                        continue

                    # Atomic TOCTOU Prevention: lock per user
                    user_lock = await get_lock(user_id)
                    async with user_lock:
                        # Offload synchronous AI engine call to thread pool via asyncio.to_thread
                        result = await asyncio.to_thread(ai_engine.audit_sai_document, optimized_bytes)

                        verified = result.get("verified", False)
                        is_valid = result.get("is_valid", True)
                        if not is_valid:
                            verified = False
                        reason = result.get("reason") or "Document could not be validated as an official STI SAI."
                        if reason == "NONE" or not reason:
                            reason = "Document could not be validated as an official STI SAI."
                        extracted_id = result.get("extracted_id", "").strip()

                        if reason == "DECOMPRESSION_BOMB":
                            if status_msg:
                                await status_msg.edit(content="❌ Image processing aborted: Decompression bomb detected (exceeded 8 Megapixel ceiling).")
                            continue

                        # PASS Logic
                        if verified:
                            extracted_data = result.get("extracted_data", {})
                            s_name = extracted_data.get("student_name")
                            prog_year = extracted_data.get("program_year") or extracted_data.get("program_year_level")
                            sy_term = extracted_data.get("school_year_term")
                            doc_date = extracted_data.get("document_date")

                            student_hash = await asyncio.to_thread(database.hash_student_id, extracted_id)
                            # Atomic TOCTOU Prevention: lock per student hash
                            hash_lock = await get_lock(student_hash)
                            async with hash_lock:
                                db_success = await asyncio.to_thread(
                                    database.add_verified_user,
                                    discord_id=user_id_str,
                                    student_id_hash=extracted_id,
                                    student_name=s_name,
                                    program_year=prog_year,
                                    school_year_term=sy_term,
                                    document_date=doc_date
                                )
                                if not db_success:
                                    # Treat as duplicate -> Fail
                                    verified = False
                                    reason = f"Duplicate verification: Student ID '{extracted_id}' is already registered to another user."

                                    # Send audit alert to MOD_LOG_CHANNEL_ID
                                    existing_record = await asyncio.to_thread(database.get_student_by_id, extracted_id)
                                    original_discord_id = existing_record["discord_id"] if existing_record else "Unknown"
                                    mod_log_id = int(os.environ.get("MOD_LOG_CHANNEL_ID", 0))
                                    guild = channel.guild if channel and hasattr(channel, "guild") else self.get_guild(int(os.environ.get("GUILD_ID", 0)))
                                    if mod_log_id and guild:
                                        try:
                                            mod_channel = guild.get_channel(mod_log_id)
                                            if not mod_channel:
                                                mod_channel = await guild.fetch_channel(mod_log_id)
                                            if mod_channel:
                                                mod_embed = discord.Embed(
                                                    title="⚠️ Duplicate Student ID Detected",
                                                    description="A student submitted a Student ID that is already registered in the system.",
                                                    color=discord.Color.gold()
                                                )
                                                mod_embed.add_field(name="Applicant", value=f"<@{user_id}>", inline=True)
                                                mod_embed.add_field(name="Existing Registered User", value=f"<@{original_discord_id}>", inline=True)
                                                if s_name:
                                                    mod_embed.add_field(name="Student Name", value=s_name, inline=True)
                                                mod_embed.add_field(
                                                    name="Action Needed",
                                                    value="Staff review required via `/check-student` or `/unlink-student`.",
                                                    inline=False
                                                )
                                                msg = await mod_channel.send(embed=mod_embed)
                                                self.sent_audit_logs[msg.id] = mod_embed
                                        except Exception as e:
                                            print(f"Failed to send mod log embed: {e}")

                                    duplicate_embed = discord.Embed(
                                        title="Verification Rejected (Duplicate Document)",
                                        description="❌ This Student Assessment Invoice (SAI) has already been registered to another Discord account. Duplicate submissions are strictly prohibited.\n\nIf you believe this is an error, please open a support ticket.",
                                        color=discord.Color.red()
                                    )
                                    if status_msg:
                                        await status_msg.edit(content="", embed=duplicate_embed, view=None)
                                    elif channel:
                                        await channel.send(embed=duplicate_embed)
                                    continue
                                else:
                                    guild_id = int(os.environ.get("GUILD_ID", 0))
                                    guild = (channel.guild if channel and hasattr(channel, "guild") else None) or self.get_guild(guild_id)
                                    role_assigned = False
                                    if guild:
                                        role = guild.get_role(int(os.environ.get("VERIFIED_ROLE_ID", 0)))
                                        # DM Member Fetch Safety: safely fetch member
                                        member = await fetch_member_safely(guild, user_id)
                                        if member and role:
                                            try:
                                                await member.add_roles(role)
                                                role_assigned = True
                                            except Exception as e:
                                                print(f"Failed to assign role to {user_id_str} on success: {e}")

                                    success_embed = discord.Embed(
                                        title="Verification Successful",
                                        description="🎉 Your student verification has been approved automatically!",
                                        color=discord.Color.green()
                                    )
                                    success_embed.add_field(name="Student ID", value=extracted_id, inline=True)
                                    if s_name:
                                        success_embed.add_field(name="Student Name", value=s_name, inline=True)
                                    if prog_year:
                                        success_embed.add_field(name="Program & Year", value=prog_year, inline=True)
                                    if sy_term:
                                        success_embed.add_field(name="School Year & Term", value=sy_term, inline=True)
                                    if doc_date:
                                        success_embed.add_field(name="Document Date", value=doc_date, inline=True)
                                    if role_assigned:
                                        success_embed.add_field(name="Role Assigned", value="Verified Student", inline=True)
                                    else:
                                        success_embed.add_field(name="Role Status", value="Role pending assignment.", inline=True)
                                        
                                    correction_view = RequestCorrectionView(
                                        user_id=user_id,
                                        image_url=item["url"],
                                        current_details=result
                                    )
                                    if status_msg:
                                        await status_msg.edit(content="✅ Analysis complete!", embed=success_embed, view=correction_view)
                                    elif channel:
                                        await channel.send(embed=success_embed, view=correction_view)
                                    continue

                        # FAIL Logic (Warning or Lock)
                        await asyncio.to_thread(database.add_strike, user_id_str)
                        updated_state = await asyncio.to_thread(database.get_user_state, user_id_str)
                        strikes = 1
                        is_locked = False
                        if updated_state:
                            strikes, is_locked = updated_state

                        if is_locked or strikes >= 2:
                            # Strike 2 (Lock user & forward to staff)
                            if status_msg:
                                await status_msg.edit(content="❌ Verification failed.")
                            
                            lock_embed = discord.Embed(
                                title="Verification Locked",
                                description=(
                                    "❌ You have accumulated 2 strikes. Your verification has been locked "
                                    "and forwarded to server staff for manual review. Please wait for assistance."
                                ),
                                color=discord.Color.red()
                            )
                            lock_embed.add_field(name="Failure Reason", value=reason, inline=False)
                            if channel:
                                await channel.send(embed=lock_embed)
                            
                            # Send to staff pending channel
                            pending_channel_id = int(os.environ.get("PENDING_CHANNEL_ID", 0))
                            guild_id = int(os.environ.get("GUILD_ID", 0))
                            guild = (channel.guild if channel and hasattr(channel, "guild") else None) or self.get_guild(guild_id)
                            pending_channel = None
                            if guild:
                                pending_channel = guild.get_channel(pending_channel_id)
                                if not pending_channel:
                                    try:
                                        pending_channel = await guild.fetch_channel(pending_channel_id)
                                    except Exception:
                                        pass
                            if not pending_channel:
                                pending_channel = self.get_channel(pending_channel_id)

                            if pending_channel:
                                view = StaffTriageView(user_id=user_id)
                                staff_embed = discord.Embed(
                                    title="Manual Verification Required",
                                    description="User has accumulated 2 strikes and is locked. Please review the attached document.",
                                    color=discord.Color.orange()
                                )
                                staff_embed.add_field(name="User Mention", value=f"<@{user_id}>", inline=True)
                                staff_embed.add_field(name="User ID", value=user_id_str, inline=True)
                                staff_embed.add_field(name="Student ID", value=extracted_id if extracted_id else "N/A", inline=True)
                                staff_embed.add_field(name="Failure Reason", value=reason, inline=False)

                                # Re-upload the optimized image buffer directly (always < 10MB, no URLs)
                                try:
                                    file_to_forward = discord.File(
                                        io.BytesIO(optimized_bytes if optimized_bytes else image_bytes), filename="sai_document.jpg"
                                    )
                                    await pending_channel.send(embed=staff_embed, file=file_to_forward, view=view)
                                except Exception as e:
                                    print(f"Failed to forward verification image to staff: {e}")
                                    await pending_channel.send(embed=staff_embed, view=view)
                        else:
                            # Strike 1: Warning
                            if status_msg:
                                await status_msg.edit(content="❌ Verification failed.")
                            
                            warn_embed = discord.Embed(
                                title="Verification Warning (Strike 1/2)",
                                description=(
                                    "⚠️ Your document verification failed. You have received 1 strike. "
                                    "You have one remaining attempt before your account is locked and sent to manual review."
                                ),
                                color=discord.Color.yellow()
                            )
                            warn_embed.add_field(name="Failure Reason", value=reason, inline=False)
                            if channel:
                                await channel.send(embed=warn_embed)

                except Exception as e:
                    # Log error and notify user via channel / staff
                    print(f"Error in verification worker processing: {e}", flush=True)
                    traceback.print_exc(file=sys.stdout)
                    sys.stdout.flush()
                    
                    # Lock user on AI error / timeout and forward to staff
                    try:
                        await asyncio.to_thread(database.add_strike, user_id_str)
                        await asyncio.to_thread(database.add_strike, user_id_str)
                    except Exception:
                        pass

                    if status_msg:
                        try:
                            await status_msg.edit(content="❌ An error occurred while analyzing your document. Forwarded to staff for manual review.")
                        except Exception:
                            pass

                    try:
                        pending_channel_id = int(os.environ.get("PENDING_CHANNEL_ID", 0))
                        guild_id = int(os.environ.get("GUILD_ID", 0))
                        guild = (channel.guild if channel and hasattr(channel, "guild") else None) or self.get_guild(guild_id)
                        pending_channel = None
                        if guild:
                            pending_channel = guild.get_channel(pending_channel_id)
                            if not pending_channel:
                                pending_channel = await guild.fetch_channel(pending_channel_id)
                        if not pending_channel:
                            pending_channel = self.get_channel(pending_channel_id)

                        if pending_channel and image_bytes:
                            view = StaffTriageView(user_id=user_id)
                            staff_embed = discord.Embed(
                                title="Manual Verification Required (AI Error / Timeout)",
                                description="The AI verification pipeline encountered an error or timeout. User has been locked. Please review the attached document.",
                                color=discord.Color.orange()
                            )
                            staff_embed.add_field(name="User Mention", value=f"<@{user_id}>", inline=True)
                            staff_embed.add_field(name="User ID", value=user_id_str, inline=True)
                            staff_embed.add_field(name="Student ID", value="N/A", inline=True)
                            staff_embed.add_field(name="Failure Reason", value=str(e), inline=False)

                            file_to_forward = discord.File(io.BytesIO(optimized_bytes if optimized_bytes else image_bytes), filename="sai_document.jpg")
                            await pending_channel.send(embed=staff_embed, file=file_to_forward, view=view)
                    except Exception as fwd_err:
                        print(f"Failed to forward error image to staff: {fwd_err}")

                finally:
                    if image_bytes is not None:
                        del image_bytes
                    if optimized_bytes is not None:
                        del optimized_bytes
                    gc.collect()
                    try:
                        ctypes.CDLL('libc.so.6').malloc_trim(0)
                    except Exception:
                        pass
                    self.verification_queue.task_done()
                    self.processing_users.discard(user_id)


# ==================== HELPER FUNCTIONS ====================

async def fetch_member_safely(guild: discord.Guild, user_id: int) -> Optional[discord.Member]:
    """
    Safely retrieves a member from the guild.
    Tries memory cache first, then API fetch.
    Handles discord.NotFound and discord.HTTPException.
    """
    try:
        member = guild.get_member(user_id)
        if not member:
            member = await guild.fetch_member(user_id)
        return member
    except (discord.NotFound, discord.HTTPException) as e:
        print(f"Failed to fetch member {user_id} safely: {e}")
        return None

async def send_audit_log(guild: Optional[discord.Guild], embed: discord.Embed) -> None:
    """
    Sends support / administrative audit log embeds to the configured MOD_LOG_CHANNEL_ID.
    Saves the message ID and its embed to prevent moderator tampering.
    """
    if not guild:
        return
    mod_log_id = int(os.environ.get("MOD_LOG_CHANNEL_ID", 0))
    if not mod_log_id:
        return
    try:
        mod_channel = guild.get_channel(mod_log_id)
        if not mod_channel:
            mod_channel = await guild.fetch_channel(mod_log_id)
        if mod_channel:
            msg = await mod_channel.send(embed=embed)
            bot.sent_audit_logs[msg.id] = embed
    except Exception as e:
        print(f"Failed to send mod log: {e}")


# ==================== PERSISTENT VIEWS ====================

class VerifyDropdown(discord.ui.Select):
    def __init__(self) -> None:
        options = [
            discord.SelectOption(
                label="Apply for Verification",
                description="Start the student verification process.",
                emoji="🎓",
                value="apply_verification"
            )
        ]
        super().__init__(
            placeholder="Select to verify your student status...",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="persistent:verify_dropdown_select"
        )

    async def callback(self, interaction: discord.Interaction) -> None:
        user = interaction.user
        
        # Immediate defer to prevent 10062 Unknown interaction expiry
        await interaction.response.defer(ephemeral=True)

        already_verified = await asyncio.to_thread(database.is_user_verified, user.id)
        if already_verified:
            await interaction.followup.send(
                "✅ You are already verified as an Alpha Member!",
                ephemeral=True
            )
            return

        # Clear session tracking dictionaries and sets so dropdown is never unresponsive
        if interaction.client and hasattr(interaction.client, "processing_users"):
            interaction.client.processing_users.discard(user.id)
        if 'active_sessions' in globals():
            active_sessions.pop(user.id, None)

        # Enforce button interaction cooldown
        cooldown_left = check_button_cooldown(user.id)
        if cooldown_left is not None:
            await interaction.followup.send(
                f"⚠️ Please wait {cooldown_left:.1f} seconds before requesting verification again.",
                ephemeral=True
            )
            return

        try:
            view = DMStartCancelView()
            embed = discord.Embed(
                title="Student Verification",
                description=(
                    "Welcome to student verification! Please click **Start Verification** to begin. "
                    "You will then be prompted to upload an image of your **Student Assessment Invoice**."
                ),
                color=discord.Color.blue()
            )
            await user.send(embed=embed, view=view)
            await interaction.followup.send(
                "✅ Verification initiated! Please check your Direct Messages to proceed.",
                ephemeral=True
            )
        except discord.Forbidden:
            print(f"[GATEWAY] Warning: Cannot deliver DM to user {user.id}. DMs closed or blocked.")
            await interaction.followup.send(
                "❌ Please enable Direct Messages from server members to apply.",
                ephemeral=True
            )

class VerifyDropdownView(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)
        self.add_item(VerifyDropdown())

class DMStartCancelView(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Start Verification",
        style=discord.ButtonStyle.success,
        custom_id="persistent:dm_start_btn"
    )
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        # Enforce button interaction cooldown
        cooldown_left = check_button_cooldown(interaction.user.id)
        if cooldown_left is not None:
            await interaction.response.send_message(
                f"⚠️ Please wait {cooldown_left:.1f} seconds.",
                ephemeral=True
            )
            return

        embed = discord.Embed(
            title="Upload Document",
            description=(
                "Please upload your **Student Assessment Invoice** (as a JPG or PNG image under 8MB) "
                "directly in this DM channel."
            ),
            color=discord.Color.gold()
        )
        await interaction.response.send_message(embed=embed)

    @discord.ui.button(
        label="Cancel",
        style=discord.ButtonStyle.danger,
        custom_id="persistent:dm_cancel_btn"
    )
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        # Enforce button interaction cooldown
        cooldown_left = check_button_cooldown(interaction.user.id)
        if cooldown_left is not None:
            await interaction.response.send_message(
                f"⚠️ Please wait {cooldown_left:.1f} seconds.",
                ephemeral=True
            )
            return
            
        # Purge user from active verification tracking / session state dictionaries
        if interaction.client and hasattr(interaction.client, "processing_users"):
            interaction.client.processing_users.discard(interaction.user.id)
        if 'active_sessions' in globals():
            active_sessions.pop(interaction.user.id, None)

        await interaction.response.send_message("❌ Verification cancelled. You can restart anytime using the dropdown.")

class RequestCorrectionView(discord.ui.View):
    def __init__(
        self,
        user_id: Optional[int] = None,
        image_url: Optional[str] = None,
        current_details: Optional[Dict[str, Any]] = None
    ) -> None:
        super().__init__(timeout=None)
        self.user_id = user_id
        self.image_url = image_url
        self.url = image_url
        self.current_details = current_details or {}

    @discord.ui.button(
        label="Report Info Mistake",
        style=discord.ButtonStyle.secondary,
        emoji="✏️",
        custom_id="report_mistake_btn"
    )
    async def report_mistake(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer(ephemeral=True)
        button.disabled = True
        try:
            await interaction.message.edit(view=self)
        except Exception:
            pass

        user_id = interaction.user.id
        user_id_str = str(user_id)

        record = await asyncio.to_thread(database.get_student_by_discord_id, user_id)
        current_name = record.get("student_name") if record else "N/A"
        current_program = record.get("program_year") if record else "N/A"
        current_term = record.get("school_year_term") if record else "N/A"
        current_date = record.get("document_date") if record else "N/A"
        current_id_hash = record.get("student_id_hash") if record else "N/A"

        image_bytes = None
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.url) as resp:
                    if resp.status == 200:
                        image_bytes = await resp.read()
        except Exception as e:
            print(f"Failed to re-download verification image for correction: {e}")

        pending_channel_id = int(os.environ.get("PENDING_CHANNEL_ID", 0))
        guild_id = int(os.environ.get("GUILD_ID", 0))
        guild = interaction.guild or bot.get_guild(guild_id)
        pending_channel = None
        if guild:
            pending_channel = guild.get_channel(pending_channel_id)
            if not pending_channel:
                try:
                    pending_channel = await guild.fetch_channel(pending_channel_id)
                except Exception:
                    pass
        if not pending_channel:
            pending_channel = bot.get_channel(pending_channel_id)

        if pending_channel:
            staff_embed = discord.Embed(
                title="📝 Student Detail Correction Requested",
                description="A verified student has requested a manual correction to their extracted document details.",
                color=discord.Color.orange()
            )
            staff_embed.add_field(name="User Mention", value=f"<@{user_id}>", inline=True)
            staff_embed.add_field(name="User ID", value=user_id_str, inline=True)
            staff_embed.add_field(name="Student ID Hash", value=current_id_hash[:16] + "..." if current_id_hash != "N/A" else "N/A", inline=True)
            staff_embed.add_field(name="Current Name", value=current_name, inline=True)
            staff_embed.add_field(name="Current Program", value=current_program, inline=True)
            staff_embed.add_field(name="Current Term", value=current_term, inline=True)
            staff_embed.add_field(name="Current Date", value=current_date, inline=True)

            view = StaffCorrectionView(user_id=user_id, current_data=record)
            try:
                if image_bytes:
                    file_to_forward = discord.File(io.BytesIO(image_bytes), filename="sai_correction.jpg")
                    await pending_channel.send(embed=staff_embed, file=file_to_forward, view=view)
                else:
                    await pending_channel.send(embed=staff_embed, view=view)
            except Exception as e:
                print(f"Failed to forward correction request to pending channel: {e}")

        if image_bytes is not None:
            del image_bytes
        gc.collect()

        await interaction.followup.send(
            "✅ Your correction request has been forwarded to server staff. You will retain your verified role while staff reviews your document.",
            ephemeral=True
        )

class StudentEditModal(discord.ui.Modal, title="Edit Student Information"):
    def __init__(self, user_id: int, origin_view: discord.ui.View = None, current_data: Optional[Dict[str, Any]] = None) -> None:
        super().__init__()
        self.user_id = user_id
        self.origin_view = origin_view
        current_data = current_data or {}

        self.student_name = discord.ui.TextInput(
            label="Student Name",
            default=current_data.get("student_name", ""),
            max_length=100,
            required=True
        )
        self.program_year = discord.ui.TextInput(
            label="Program & Year",
            default=current_data.get("program_year", ""),
            max_length=50,
            required=True
        )
        self.school_year_term = discord.ui.TextInput(
            label="School Year & Term",
            default=current_data.get("school_year_term", ""),
            max_length=50,
            required=True
        )
        self.document_date = discord.ui.TextInput(
            label="Document Date",
            default=current_data.get("document_date", ""),
            max_length=30,
            required=True
        )

        self.add_item(self.student_name)
        self.add_item(self.program_year)
        self.add_item(self.school_year_term)
        self.add_item(self.document_date)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        name = self.student_name.value.strip()
        program = self.program_year.value.strip()
        term = self.school_year_term.value.strip()
        date = self.document_date.value.strip()

        await asyncio.to_thread(
            database.update_student_details,
            self.user_id,
            name,
            program,
            term,
            date
        )

        if interaction.message and interaction.message.embeds:
            embed = interaction.message.embeds[0]
            new_embed = discord.Embed.from_dict(embed.to_dict())
            new_embed.color = discord.Color.green()
            new_embed.add_field(name="Status", value=f"✅ Corrected by {interaction.user.mention}", inline=False)
            
            if self.origin_view:
                for child in self.origin_view.children:
                    child.disabled = True
                await interaction.response.edit_message(embed=new_embed, view=self.origin_view)
            else:
                await interaction.response.edit_message(embed=new_embed)
        else:
            await interaction.response.send_message("Student details updated successfully.", ephemeral=True)

        guild = interaction.guild
        target_member = await fetch_member_safely(guild, self.user_id) if guild else None
        if target_member:
            try:
                dm_embed = discord.Embed(
                    title="Student Information Updated",
                    description=f"🎉 Staff has corrected your student information:\n**Name:** {name}\n**Program:** {program}\n**Term:** {term}\n**Date:** {date}",
                    color=discord.Color.green()
                )
                await target_member.send(embed=dm_embed)
            except discord.Forbidden:
                print(f"[GATEWAY] Warning: Cannot deliver DM to user {self.user_id}. DMs closed or blocked.")
            except Exception as e:
                print(f"Failed to DM corrected student {self.user_id}: {e}")

        if guild:
            log_embed = discord.Embed(
                title="✏️ Support Audit Log: Student Details Corrected",
                description=f"Staff {interaction.user.mention} corrected student information for <@{self.user_id}>.",
                color=discord.Color.green()
            )
            log_embed.add_field(name="Student", value=f"<@{self.user_id}>", inline=True)
            log_embed.add_field(name="Name", value=name, inline=True)
            log_embed.add_field(name="Program", value=program, inline=True)
            log_embed.add_field(name="Term", value=term, inline=True)
            log_embed.add_field(name="Date", value=date, inline=True)
            await send_audit_log(guild, log_embed)

class StaffTriageView(discord.ui.View):
    def __init__(self, user_id: Optional[int] = None) -> None:
        super().__init__(timeout=None)
        self.user_id = user_id

    @discord.ui.button(
        label="Accept",
        style=discord.ButtonStyle.success,
        custom_id="persistent:staff_accept_btn"
    )
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message("❌ Error: Must be used in a server.", ephemeral=True)
            return
            
        # Privilege Verification (Anti-Spoofing): Bypass cached interaction.user.roles
        try:
            member = await guild.fetch_member(interaction.user.id)
        except Exception:
            await interaction.response.send_message("❌ Error: Member not found.", ephemeral=True)
            return
            
        support_role_id = int(os.environ.get("SUPPORT_ROLE_ID", 0))
        is_authorized = any(role.id == support_role_id for role in member.roles) or member.guild_permissions.administrator
        if not is_authorized:
            await interaction.response.send_message("❌ No permission.", ephemeral=True)
            return
            
        if not interaction.message or not interaction.message.embeds:
            await interaction.response.send_message("❌ Error: Embed message not found.", ephemeral=True)
            return
            
        embed = interaction.message.embeds[0]
        user_id = None
        student_id = None
        for field in embed.fields:
            if field.name == "User ID":
                user_id = int(field.value)
            elif field.name == "Student ID":
                student_id = field.value
                
        if not user_id:
            await interaction.response.send_message("❌ Error: Could not parse User ID.", ephemeral=True)
            return
            
        # Atomic TOCTOU Prevention: lock per student hash during manual approval
        student_hash = await asyncio.to_thread(database.hash_student_id, student_id)
        hash_lock = await get_lock(student_hash)
        async with hash_lock:
            is_used_by_other = False
            if student_id and student_id != "N/A" and student_id.strip():
                is_used_by_other = await asyncio.to_thread(
                    database.is_student_id_used_by_other, student_id, str(user_id)
                )
                        
            if is_used_by_other:
                # Disable buttons to prevent further actions
                for child in self.children:
                    child.disabled = True
                    
                new_embed = discord.Embed.from_dict(embed.to_dict())
                new_embed.color = discord.Color.red()
                new_embed.add_field(
                    name="❌ Verification Blocked",
                    value=f"Duplicate Student ID detected: Student ID '{student_id}' is already registered to another Discord user. Approval blocked.",
                    inline=False
                )
                await interaction.response.edit_message(embed=new_embed, view=self)
                return

            # Action: Unlock user & verify them (offloaded)
            await asyncio.to_thread(database.unlock_user, str(user_id))
            if student_id and student_id != "N/A" and student_id.strip():
                await asyncio.to_thread(database.add_verified_user, str(user_id), student_id)
            else:
                await asyncio.to_thread(database.add_verified_user, str(user_id), f"STAFF_VERIFIED_{user_id}")
                
        # DM Member Fetch Safety: safely retrieve member
        target_member = await fetch_member_safely(guild, user_id)
                
        verified_role_id = int(os.environ.get("VERIFIED_ROLE_ID", 0))
        role_assigned = False
        if target_member:
            role = guild.get_role(verified_role_id)
            if role:
                try:
                    await target_member.add_roles(role)
                    role_assigned = True
                except Exception as e:
                    print(f"Failed to assign role to {user_id}: {e}")
                    
        # Notify user
        if target_member:
            try:
                success_embed = discord.Embed(
                    title="Verification Approved",
                    description="🎉 Congratulations! Your student verification has been approved by staff.",
                    color=discord.Color.green()
                )
                await target_member.send(embed=success_embed)
            except discord.Forbidden:
                print(f"[GATEWAY] Warning: Cannot deliver DM to user {user_id}. DMs closed or blocked.")
            except Exception as e:
                print(f"Failed to DM approved user {user_id}: {e}")
                
        # Disable buttons
        for child in self.children:
            child.disabled = True
            
        new_embed = discord.Embed.from_dict(embed.to_dict())
        new_embed.color = discord.Color.green()
        new_embed.add_field(name="Status", value=f"✅ Approved by {member.mention}", inline=False)
        await interaction.response.edit_message(embed=new_embed, view=self)

    @discord.ui.button(
        label="Deny",
        style=discord.ButtonStyle.danger,
        custom_id="persistent:staff_deny_btn"
    )
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message("❌ Error: Must be used in a server.", ephemeral=True)
            return
            
        # Privilege Verification (Anti-Spoofing): Bypass cached interaction.user.roles
        try:
            member = await guild.fetch_member(interaction.user.id)
        except Exception:
            await interaction.response.send_message("❌ Error: Member not found.", ephemeral=True)
            return
            
        support_role_id = int(os.environ.get("SUPPORT_ROLE_ID", 0))
        is_authorized = any(role.id == support_role_id for role in member.roles) or member.guild_permissions.administrator
        if not is_authorized:
            await interaction.response.send_message("❌ No permission.", ephemeral=True)
            return
            
        if not interaction.message or not interaction.message.embeds:
            await interaction.response.send_message("❌ Error: Embed message not found.", ephemeral=True)
            return
            
        embed = interaction.message.embeds[0]
        user_id = None
        for field in embed.fields:
            if field.name == "User ID":
                user_id = int(field.value)
                
        if not user_id:
            await interaction.response.send_message("❌ Error: Could not parse User ID.", ephemeral=True)
            return
            
        # Action: Unlock user so they can try again, but do not verify (offloaded)
        await asyncio.to_thread(database.unlock_user, str(user_id))
        
        # DM Member Fetch Safety: safely retrieve member
        target_member = await fetch_member_safely(guild, user_id)
                
        if target_member:
            try:
                deny_embed = discord.Embed(
                    title="Verification Denied",
                    description="❌ Your student student verification request was denied by staff. You may try re-submitting your document.",
                    color=discord.Color.red()
                )
                await target_member.send(embed=deny_embed)
            except discord.Forbidden:
                print(f"[GATEWAY] Warning: Cannot deliver DM to user {user_id}. DMs closed or blocked.")
            except Exception as e:
                print(f"Failed to DM denied user {user_id}: {e}")
                
        # Disable buttons
        for child in self.children:
            child.disabled = True
            
        new_embed = discord.Embed.from_dict(embed.to_dict())
        new_embed.color = discord.Color.red()
        new_embed.add_field(name="Status", value=f"❌ Denied by {member.mention}", inline=False)
        await interaction.response.edit_message(embed=new_embed, view=self)

class StaffCorrectionView(discord.ui.View):
    def __init__(self, user_id: Optional[int] = None, current_data: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(timeout=None)
        self.user_id = user_id
        self.current_data = current_data

    @discord.ui.button(
        label="Edit Details",
        style=discord.ButtonStyle.primary,
        emoji="✏️",
        custom_id="persistent:staff_edit_details_btn"
    )
    async def edit_details(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message("❌ Error: Must be used in a server.", ephemeral=True)
            return

        try:
            member = await guild.fetch_member(interaction.user.id)
        except Exception:
            await interaction.response.send_message("❌ Error: Member not found.", ephemeral=True)
            return

        support_role_id = int(os.environ.get("SUPPORT_ROLE_ID", 0))
        is_authorized = any(role.id == support_role_id for role in member.roles) or member.guild_permissions.administrator
        if not is_authorized:
            await interaction.response.send_message("❌ No permission.", ephemeral=True)
            return

        if not interaction.message or not interaction.message.embeds:
            await interaction.response.send_message("❌ Error: Embed message not found.", ephemeral=True)
            return

        embed = interaction.message.embeds[0]
        parsed_user_id = self.user_id
        if not parsed_user_id:
            for field in embed.fields:
                if field.name == "User ID":
                    try:
                        parsed_user_id = int(field.value)
                    except ValueError:
                        pass

        if not parsed_user_id:
            await interaction.response.send_message("❌ Error: Could not parse User ID.", ephemeral=True)
            return

        record = self.current_data
        if not record:
            record = await asyncio.to_thread(database.get_student_by_discord_id, parsed_user_id)

        modal = StudentEditModal(user_id=parsed_user_id, origin_view=self, current_data=record)
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="Dismiss",
        style=discord.ButtonStyle.secondary,
        custom_id="persistent:staff_dismiss_btn"
    )
    async def dismiss(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        guild = interaction.guild
        if not guild:
            await interaction.response.send_message("❌ Error: Must be used in a server.", ephemeral=True)
            return

        try:
            member = await guild.fetch_member(interaction.user.id)
        except Exception:
            await interaction.response.send_message("❌ Error: Member not found.", ephemeral=True)
            return

        support_role_id = int(os.environ.get("SUPPORT_ROLE_ID", 0))
        is_authorized = any(role.id == support_role_id for role in member.roles) or member.guild_permissions.administrator
        if not is_authorized:
            await interaction.response.send_message("❌ No permission.", ephemeral=True)
            return

        if not interaction.message or not interaction.message.embeds:
            await interaction.response.send_message("❌ Error: Embed message not found.", ephemeral=True)
            return

        embed = interaction.message.embeds[0]
        for child in self.children:
            child.disabled = True

        new_embed = discord.Embed.from_dict(embed.to_dict())
        new_embed.color = discord.Color.light_gray()
        new_embed.add_field(name="Status", value=f"ℹ️ Dismissed by {member.mention} (No changes made)", inline=False)
        await interaction.response.edit_message(embed=new_embed, view=self)
        await interaction.followup.send("✅ Correction request dismissed.", ephemeral=True)


bot = VerificationBot()

# ==================== BOT SLASH COMMANDS ====================

async def is_staff_or_admin(interaction: discord.Interaction) -> bool:
    """
    Checks if the interacting user has the configured Support role or is an Admin.
    Bypasses cached roles, explicitly fetching the member from Discord API.
    """
    if not interaction.guild:
        return False
    support_role_id = int(os.environ.get("SUPPORT_ROLE_ID", 0))
    try:
        member = await interaction.guild.fetch_member(interaction.user.id)
    except Exception:
        return False
        
    if any(role.id == support_role_id for role in member.roles):
        return True
    if member.guild_permissions.administrator:
        return True
    return False


@bot.tree.command(name="setup-verify", description="Sets up the student verification channel with the dropdown menu.")
@app_commands.checks.cooldown(1, 60.0, key=lambda i: (i.guild_id or 0, i.user.id))
async def setup_verify(interaction: discord.Interaction) -> None:
    # Restrict to Support Role or Admin
    if not await is_staff_or_admin(interaction):
        await interaction.response.send_message("❌ You do not have permission to run this command.", ephemeral=True)
        return

    verify_channel_id = int(os.environ.get("VERIFY_CHANNEL_ID", 0))
    channel = bot.get_channel(verify_channel_id)
    if not channel:
        await interaction.response.send_message(
            f"❌ Verification channel with ID {verify_channel_id} not found in cache. Make sure the bot has access.",
            ephemeral=True
        )
        return
        
    embed = discord.Embed(
        title="Student Verification Required",
        description="To access the channels on this server, please verify your student status by choosing an option below.",
        color=discord.Color.blue()
    )
    view = VerifyDropdownView()
    await channel.send(embed=embed, view=view)
    await interaction.response.send_message("✅ Verification dropdown posted successfully!", ephemeral=True)


@bot.tree.command(name="check-student", description="Inspect a student's verification status by Student ID or User.")
@app_commands.describe(student_id="Raw Student ID", user="Discord user to check")
@app_commands.checks.cooldown(1, 60.0, key=lambda i: (i.guild_id or 0, i.user.id))
async def check_student(
    interaction: discord.Interaction,
    student_id: Optional[str] = None,
    user: Optional[discord.User] = None
) -> None:
    if not await is_staff_or_admin(interaction):
        await interaction.response.send_message("❌ You do not have permission to run this command.", ephemeral=True)
        return

    if not student_id and not user:
        await interaction.response.send_message("❌ Please specify either a student_id or a user.", ephemeral=True)
        return

    record = None
    if user:
        record = await asyncio.to_thread(database.get_student_by_discord_id, user.id)
    elif student_id:
        record = await asyncio.to_thread(database.get_student_by_id, student_id)

    if not record:
        await interaction.response.send_message("❌ No verification record found.", ephemeral=True)
        return

    discord_id = record["discord_id"]
    timestamp = record.get("timestamp", "N/A")
    student_id_hash = record.get("student_id_hash", "N/A")

    user_state = await asyncio.to_thread(database.get_user_state, str(discord_id))
    if user_state:
        strikes, is_locked = user_state
        status = "Locked" if is_locked else f"Active ({strikes} strikes)"
    else:
        status = "Verified"

    embed = discord.Embed(
        title="Student Verification Info",
        color=discord.Color.blue()
    )
    embed.add_field(name="Registered User", value=f"<@{discord_id}> ({discord_id})", inline=False)
    embed.add_field(name="Student ID Hash", value=student_id_hash, inline=False)
    embed.add_field(name="Student Name", value=record.get("student_name") or "N/A", inline=True)
    embed.add_field(name="Program & Year", value=record.get("program_year") or "N/A", inline=True)
    embed.add_field(name="School Year & Term", value=record.get("school_year_term") or "N/A", inline=True)
    embed.add_field(name="Document Date", value=record.get("document_date") or "N/A", inline=True)
    embed.add_field(name="Registration Date", value=timestamp, inline=True)
    embed.add_field(name="Current Status", value=status, inline=True)

    await interaction.response.send_message(embed=embed, ephemeral=True)

    # Automated Support Audit Log Embed to MOD_LOG_CHANNEL_ID
    log_embed = discord.Embed(
        title="🔍 Support Audit Log: Student Inspected",
        description=f"Moderator {interaction.user.mention} inspected verification status.",
        color=discord.Color.blue()
    )
    if user:
        log_embed.add_field(name="Inspected User", value=f"<@{user.id}> ({user.id})", inline=True)
    if student_id:
        log_embed.add_field(name="Inspected Student ID", value=student_id, inline=True)
    await send_audit_log(interaction.guild, log_embed)


@bot.tree.command(name="unlink-student", description="Remove a student's verification record and role by Student ID or User.")
@app_commands.describe(student_id="Raw Student ID", user="Discord user to unlink")
@app_commands.checks.cooldown(1, 60.0, key=lambda i: (i.guild_id or 0, i.user.id))
async def unlink_student(
    interaction: discord.Interaction,
    student_id: Optional[str] = None,
    user: Optional[discord.User] = None
) -> None:
    if not await is_staff_or_admin(interaction):
        await interaction.response.send_message("❌ You do not have permission to run this command.", ephemeral=True)
        return

    if not student_id and not user:
        await interaction.response.send_message("❌ Please specify either a student_id or a user.", ephemeral=True)
        return

    target_discord_id = None
    deleted = False

    if user:
        target_discord_id = user.id
        deleted = await asyncio.to_thread(database.delete_student_by_discord_id, user.id)
    elif student_id:
        record = await asyncio.to_thread(database.get_student_by_id, student_id)
        if record:
            target_discord_id = record["discord_id"]
        deleted = await asyncio.to_thread(database.delete_student_record, student_id)

    if not deleted and not target_discord_id:
        await interaction.response.send_message("❌ No record found to unlink.", ephemeral=True)
        return

    if target_discord_id and interaction.guild:
        verified_role_id = int(os.environ.get("VERIFIED_ROLE_ID", 0))
        role = interaction.guild.get_role(verified_role_id)
        member = await fetch_member_safely(interaction.guild, target_discord_id)
        if member and role and role in member.roles:
            try:
                await member.remove_roles(role)
            except Exception as e:
                print(f"Failed to remove role on unlink: {e}")

    await interaction.response.send_message("✅ Unlinked Student ID/User. They can now re-run verification.", ephemeral=True)

    # Automated Support Audit Log Embed to MOD_LOG_CHANNEL_ID
    log_embed = discord.Embed(
        title="🗑️ Support Audit Log: Student Unlinked",
        description=f"Moderator {interaction.user.mention} unlinked verification record.",
        color=discord.Color.red()
    )
    if user:
        log_embed.add_field(name="Unlinked User", value=f"<@{user.id}> ({user.id})", inline=True)
    if student_id:
        log_embed.add_field(name="Unlinked Student ID", value=student_id, inline=True)
    await send_audit_log(interaction.guild, log_embed)


@bot.tree.command(name="force-verify", description="Manually force-verify a user with a Student ID.")
@app_commands.describe(user="Discord user to verify", student_id="Student ID to assign")
@app_commands.checks.cooldown(1, 60.0, key=lambda i: (i.guild_id or 0, i.user.id))
async def force_verify(
    interaction: discord.Interaction,
    user: discord.User,
    student_id: str
) -> None:
    if not await is_staff_or_admin(interaction):
        await interaction.response.send_message("❌ You do not have permission to run this command.", ephemeral=True)
        return

    # Delete existing link for user or student_id first (offloaded)
    await asyncio.to_thread(database.delete_student_by_discord_id, user.id)
    await asyncio.to_thread(database.delete_student_record, student_id)

    # Force register and unlock (offloaded)
    await asyncio.to_thread(database.add_verified_user, str(user.id), student_id)
    await asyncio.to_thread(database.unlock_user, str(user.id))

    if interaction.guild:
        verified_role_id = int(os.environ.get("VERIFIED_ROLE_ID", 0))
        role = interaction.guild.get_role(verified_role_id)
        member = await fetch_member_safely(interaction.guild, user.id)
        if member and role:
            try:
                await member.add_roles(role)
            except Exception as e:
                print(f"Failed to assign role on force-verify: {e}")

    await interaction.response.send_message(f"✅ Manually verified <@{user.id}> with Student ID {student_id}.", ephemeral=True)

    # Automated Support Audit Log Embed to MOD_LOG_CHANNEL_ID
    log_embed = discord.Embed(
        title="✅ Support Audit Log: Student Force Verified",
        description=f"Moderator {interaction.user.mention} force-verified a student.",
        color=discord.Color.green()
    )
    log_embed.add_field(name="Force Verified User", value=f"<@{user.id}> ({user.id})", inline=True)
    log_embed.add_field(name="Assigned Student ID", value=student_id, inline=True)
    await send_audit_log(interaction.guild, log_embed)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError) -> None:
    """
    Global app command error handler to capture cooldown exceptions.
    """
    if isinstance(error, app_commands.CommandOnCooldown):
        await interaction.response.send_message(
            f"⚠️ This command is on cooldown. Please try again in {error.retry_after:.1f} seconds.",
            ephemeral=True
        )
    else:
        print(f"App command error: {error}")
        try:
            await interaction.response.send_message(f"❌ An error occurred: {error}", ephemeral=True)
        except Exception:
            pass


# ==================== BOT EVENTS ====================

@bot.event
async def on_ready() -> None:
    await asyncio.to_thread(database.checkpoint_db)
    database.reset_all_locks()
    print(f"[GATEWAY] Logged in as {bot.user} (ID: {bot.user.id if bot.user else 'Unknown'})", flush=True)

@bot.event
async def on_message(message: discord.Message) -> None:
    if message.author.bot:
        return

    is_dm = isinstance(message.channel, discord.DMChannel)
    print(f"[GATEWAY EVENT] Message received from {message.author} (ID: {message.author.id}) | Is DM: {is_dm} | Attachments: {len(message.attachments)}", flush=True)

    # Check if DM channel
    if message.guild is not None:
        await bot.process_commands(message)
        return

    # If it's a DM, make sure there is an attachment
    if not message.attachments:
        if is_dm:
            print(f"[IGNORED] User {message.author.id} sent text without an image attachment in DMs: {message.content!r}", flush=True)
        return

    user_id = message.author.id
    user_id_str = str(user_id)

    already_verified = await asyncio.to_thread(database.is_user_verified, message.author.id)
    if already_verified:
        try:
            await message.author.send("✅ You are already verified as an Alpha Member! If you need to correct your student information, use the 'Report Info Mistake' button or contact staff.")
        except Exception:
            try:
                await message.reply("✅ You are already verified as an Alpha Member! If you need to correct your student information, use the 'Report Info Mistake' button or contact staff.")
            except Exception:
                pass
        return

    # Enforce attachment length check
    if len(message.attachments) > 1:
        try:
            await message.author.send("⚠️ Please upload only 1 SAI document at a time.")
        except discord.Forbidden:
            print(f"[GATEWAY] Warning: Cannot deliver DM to user {user_id}. DMs closed or blocked.")
        except Exception:
            try:
                await message.reply("⚠️ Please upload only 1 SAI document at a time.")
            except Exception:
                pass
        return
    
    # In-flight DM Locking: check if user is already being processed or if locked in DB
    if user_id in bot.processing_users:
        await message.reply("❌ Please wait until your current document analysis completes.")
        return

    user_state = await asyncio.to_thread(database.get_user_state, user_id_str)
    if user_state is not None:
        strikes, is_locked = user_state
        if is_locked:
            print(f"[REJECTED] User {message.author.id} is LOCKED in database. Prompting user...", flush=True)
            try:
                await message.reply("🔒 Your verification is currently locked due to previous failed attempts. Please wait for staff to review your submission in #pending-submissions.")
            except Exception:
                pass
            return

    # Process first attachment
    attachment = message.attachments[0]
    
    # MIME type validation: accept ONLY image/jpeg or image/png
    is_valid_type = False
    if attachment.content_type:
        is_valid_type = attachment.content_type in ["image/jpeg", "image/png"]
    else:
        ext = os.path.splitext(attachment.filename)[1].lower()
        is_valid_type = ext in [".jpg", ".jpeg", ".png"]

    # Ephemeral reject for unsupported file formats
    if not is_valid_type:
        await message.reply("❌ Invalid file. Please upload a JPG or PNG image under 8MB.")
        return

    # Pre-download check: Inspect attachment.size against 8MB limit
    if attachment.size > MAX_FILE_SIZE:
        try:
            await message.author.send("⚠️ File too large. Maximum size is 25MB.")
        except Exception:
            try:
                await message.reply("⚠️ File too large. Maximum size is 25MB.")
            except Exception:
                pass
        return

    # Check queue depth backpressure
    if verification_queue.qsize() >= MAX_QUEUE_DEPTH:
        await message.reply("⚠️ Verification traffic is currently high. Please retry in 1-2 minutes.")
        return

    # Add to processing_users and queue ONLY metadata dict
    bot.processing_users.add(user_id)
    meta = {
        "url": attachment.url,
        "user_id": user_id,
        "channel_id": message.channel.id
    }
    await verification_queue.put(meta)
    await message.reply(f"⏳ Added to the verification queue! You are currently position: {verification_queue.qsize()}.")


@bot.event
async def on_message_delete(message: discord.Message) -> None:
    """
    Prevents audit log spoofing or deletion.
    If an audit log message from MOD_LOG_CHANNEL_ID is deleted, re-sends it and notifies owner.
    """
    if message.id in bot.sent_audit_logs:
        original_embed = bot.sent_audit_logs[message.id]
        guild = message.guild
        
        # If message.guild is not populated, resolve via environment variable
        guild_id = int(os.environ.get("GUILD_ID", 0))
        if not guild and guild_id:
            guild = bot.get_guild(guild_id)
            
        if not guild:
            return
            
        mod_log_id = int(os.environ.get("MOD_LOG_CHANNEL_ID", 0))
        mod_channel = guild.get_channel(mod_log_id)
        if not mod_channel:
            try:
                mod_channel = await guild.fetch_channel(mod_log_id)
            except Exception:
                pass
                
        if mod_channel:
            # Determine appropriate recipient to notify (tag Server Owner or fallback)
            owner_mention = guild.owner.mention if (guild and guild.owner) else "@Server Owner"
            
            warning_embed = discord.Embed(
                title="🚨 SECURITY ALERT: Audit Log Tampered",
                description=(
                    f"An audit log message was deleted! Re-creating original log below.\n"
                    f"Attention: {owner_mention}"
                ),
                color=discord.Color.red()
            )
            # Re-send security alert warning
            await mod_channel.send(
                content=f"⚠️ {owner_mention} **SECURITY ALERT: Audit Log Tampered**",
                embed=warning_embed
            )
            # Re-create and cache the original log embed
            new_msg = await mod_channel.send(embed=original_embed)
            bot.sent_audit_logs[new_msg.id] = original_embed


if __name__ == "__main__":
    import preflight
    # Run gatekeeper checks prior to establishing gateway connection
    try:
        if not (preflight.check_env_variables() and preflight.check_database() and preflight.check_gemini_api()):
            raise RuntimeError("Preflight validation checks failed.")
    except Exception as e:
        print(f"[FATAL] Preflight validation failed: {e}")
        exit(1)
    
    TOKEN = os.getenv("DISCORD_TOKEN")
    bot.run(TOKEN)
